﻿using NexVega.Core.Interfaces;
using System.ComponentModel.DataAnnotations.Schema;

namespace NexVega.Core.Models
{
    [Table("User")]
    public class UserDetails : IEntity
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public int Age { get; set; }
        public string Gender { get; set; }
        public string Location { get; set; }
        public bool IsActive { get; set; }
        public List<UserDetails>? Friends { get; set; }

    }
}
