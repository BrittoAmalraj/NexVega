﻿using NexVega.Core.Models;

namespace NexVega.Core.Interfaces
{
    public interface IUserRepository : IGenericRepository<UserDetails>
    {
        Task<IEnumerable<UserDetails>> GetFriendSuggestions(UserDetails currentUser);

        Task<List<string>> GetFriendSuggestionsUsingBFS(string user, Dictionary<string, List<string>> friendLists);
    }
}
