﻿

using NexVega.Core.Interfaces;

namespace NexVega.Core.Interfaces
{
    public interface IUnitOfWork : IDisposable
    {
        IUserRepository Friends { get; }

        int Save();
    }
}
