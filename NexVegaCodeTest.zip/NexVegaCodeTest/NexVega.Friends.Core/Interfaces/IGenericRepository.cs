﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NexVega.Core.Interfaces
{
    public interface IGenericRepository<T> where T : class
    {
        IQueryable<T> GetAll();

        Task<T> GetById(int id);

        Task<int> Create(T entity);

        Task<int> Update(int id, T entity);

        Task<int> Delete(int id);
    }
}
