﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using NexVega.Core.Models;
using NexVega.Services.Interfaces;
using System.Reflection.Metadata.Ecma335;

namespace NexVega.Controllers
{
    
    [ApiController]
    [Route("api/[controller]")]
    [Produces("application/json")]
    public class FriendsController : ControllerBase
    {
        public readonly IFriendsService _friendsService;
        private readonly ILogger<FriendsController> _logger;

        public FriendsController(IFriendsService friendsService, ILogger<FriendsController> logger)
        {
            _friendsService = friendsService;
            _logger = logger;

        }

        /// <summary>
        ///  Given a user's friend list and the friend lists of their friends, return a list of potential new friends (friends of friends)
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [Route("GetFriendSuggestions")]
        public async Task<IEnumerable<UserDetails>> GetFriendSuggestions()
        {
            try
            {
                //Creates three sample users (Hareesh, Bryson, Bryna) and establishes friendships between them.
                //Hareesh friend of Bryson
                //Bryson friend of Hareesh
                //Bryson friend of Bryna
                //Bryna friemd of Bryson
                var user_Hareesh = await _friendsService.AddFriends();

                //GetFriendSuggestions() function for user Hareesh to get suggested friends based on the friend network.
                var friendSuggestions = await _friendsService.GetFriendSuggestions(user_Hareesh);
                return friendSuggestions;
            }
            catch (Exception ex)
            {
                _logger.LogError("GetFriendSuggestions:" + ex.StackTrace + ex.Message);
               return null;
            }
        }


        /// <summary>
        ///  Given a user's friend list and the friend lists of their friends, return a list of potential new friends (friends of friends)
        ///  Graph traversal algorithm -  Breadth-First Search (BFS)
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [Route("GetFindPotentialFriendsUsingBFS")]
        public async Task<IActionResult> GetFriendSuggestionsUsingBFS()
        {
            try
            {
                //Creates three sample users(Hareesh, Bryson, Bryna) and establishes friendships between them.
                Dictionary<string, List<string>> friendLists = new Dictionary<string, List<string>>
            {
                {"Hareesh", new List<string>{ "Bryson", "Monica", "Berlin"}},
                {"Bryson", new List<string>{ "Hareesh", "Jason"}},
                {"Monica", new List<string>{ "Hareesh", "Berlin"}},
                {"Berlin", new List<string>{ "Hareesh", "Monica"}},
                {"Jason", new List<string>{"Bryson"}}
            };

                //Dictionary<UserDetails, List<UserDetails>> friendLists = new Dictionary<UserDetails, List<UserDetails>>();
                //friendLists.Add(new UserDetails() { Name = "Hareesh" }, new List<UserDetails>() { new UserDetails() { Name = "Bryson" }, new UserDetails() { Name = "Monica" }, new UserDetails() { Name = "Berlin" } });
                //friendLists.Add(new UserDetails() { Name = "Bryson" }, new List<UserDetails>() { new UserDetails() { Name = "Hareesh" }, new UserDetails() { Name = "Jason" } });
                //friendLists.Add(new UserDetails() { Name = "Monica" }, new List<UserDetails>() { new UserDetails() { Name = "Hareesh" }, new UserDetails() { Name = "Berlin" } });
                //friendLists.Add(new UserDetails() { Name = "Berlin" }, new List<UserDetails>() { new UserDetails() { Name = "Hareesh" }, new UserDetails() { Name = "Monica" } });
                //friendLists.Add(new UserDetails() { Name = "Jason" }, new List<UserDetails>() { new UserDetails() { Name = "Bryson" } });

                List<string> potentialFriends = await _friendsService.GetFriendSuggestionsUsingBFS("Hareesh", friendLists);
                return Ok(potentialFriends);
            }
            catch (Exception ex)
            {
                _logger.LogError("GetFriendSuggestions:" + ex.StackTrace + ex.Message);
                throw;
            }
           
        }
        
        [HttpGet("{userId}")]
        public async Task<IActionResult> GetUserDetail(int userId)
        {
            if (userId < 1)
                return BadRequest();
            var user = await _friendsService.GetUserDetail(userId);
            if (user == null)
                return NotFound();
            return Ok(user);
        }
    }
}
