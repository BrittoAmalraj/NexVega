﻿using Microsoft.EntityFrameworkCore;
using NexVega.Core.Models;

namespace NexVega.Infrastructure
{
    public class DbContextClass : DbContext
    {
        public DbContextClass(DbContextOptions<DbContextClass> contextOptions) : base(contextOptions)
        {

        }

        public DbSet<UserDetails> Friends { get; set; }
    }
}
