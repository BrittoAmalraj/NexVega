﻿using Microsoft.EntityFrameworkCore;
using NexVega.Core.Interfaces;
using NexVega.Core.Models;

namespace NexVega.Infrastructure.Repositories
{
    public class FriendsRepository : GenericRepository<UserDetails>, IUserRepository
    {
        public FriendsRepository(DbContextClass dbContext) : base(dbContext)
        {

        }

        /// <summary>
        ///  Given a user's friend list and the friend lists of their friends, return a list of potential new friends (friends of friends)
        /// </summary>
        /// <returns></returns>
        public async Task<IEnumerable<UserDetails>> GetFriendSuggestions(UserDetails currentUser)
        {
            // Initialize a dictionary to count occurrences of each potential friend
            Dictionary<UserDetails, int> friendOccurrences = new Dictionary<UserDetails, int>();

            // Iterate over each friend of the user
            foreach (var friend in currentUser.Friends)
            {
                // Iterate over each friend of the current friend (i.e., potential suggestions)
                foreach (var potentialFriend in friend.Friends)
                {
                    // Ensure the potential friend is not already a friend of the user
                    if (potentialFriend != currentUser && !currentUser.Friends.Contains(potentialFriend))
                    {
                        // Increment occurrence count of potential friend
                        if (friendOccurrences.ContainsKey(potentialFriend))
                        {
                            friendOccurrences[potentialFriend]++;
                        }
                        else
                        {
                            friendOccurrences.Add(potentialFriend, 1);
                        }
                    }
                }
            }

            // Order potential friends by occurrence count (descending) and then by username (ascending)
            var suggestedFriends = friendOccurrences.OrderByDescending(x => x.Value)
                                                    .ThenBy(x => x.Key.Name)
                                                    .Select(x => x.Key)
                                                    .ToList();

            return suggestedFriends;


        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="user"></param>
        /// <param name="friendLists"></param>
        /// <returns></returns>
        public async Task<List<string>> GetFriendSuggestionsUsingBFS(string user, Dictionary<string, List<string>> friendLists)
        {
            // Use BFS to find friends of friends
            Queue<string> queue = new Queue<string>();
            HashSet<string> visited = new HashSet<string>();
            List<string> friendsOfFriends = new List<string>();

            // Start BFS with the given user
            queue.Enqueue(user);
            visited.Add(user);

            while (queue.Count > 0)
            {
                string current = queue.Dequeue();

                // Get current user's friends
                if (friendLists.ContainsKey(current))
                {
                    List<string> friends = friendLists[current];

                    // Add friends to the list of friends of friends
                    foreach (string friend in friends)
                    {
                        if (!visited.Contains(friend))
                        {
                            visited.Add(friend);
                            friendsOfFriends.Add(friend);
                            queue.Enqueue(friend);
                        }
                    }
                }
            }

            return friendsOfFriends;
        }

    }
}
