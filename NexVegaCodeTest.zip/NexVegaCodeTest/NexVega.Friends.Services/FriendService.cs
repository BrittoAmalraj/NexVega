﻿using NexVega.Core.Interfaces;
using NexVega.Core.Models;
using NexVega.Services.Interfaces;

namespace NexVega.Services
{
    public class FriendService : IFriendsService
    {
        public IUnitOfWork _unitOfWork;

        public FriendService(IUnitOfWork unitOfWork)
        {
            _unitOfWork = unitOfWork;
        }

        /// <summary>
        /// Get friends of friends
        /// </summary>
        /// <returns></returns>
        public async Task<IEnumerable<UserDetails>> GetFriendSuggestions(UserDetails userDetails)
        {
            // Create some users         

            var friendslist = await _unitOfWork.Friends.GetFriendSuggestions(userDetails);
            return friendslist;
        } 
        public async Task<List<string>> GetFriendSuggestionsUsingBFS(string user, Dictionary<string, List<string>> friendLists)
        {
            // Create some users         

            var friendslist = await _unitOfWork.Friends.GetFriendSuggestionsUsingBFS(user,friendLists);
            return friendslist;
        }

        /// <summary>
        /// Search friend by name
        /// </summary>
        /// <returns></returns>
        public async Task<IEnumerable<UserDetails>> SearchFriends(string userName)
        {
            var friendsList = _unitOfWork.Friends.GetAll().ToList();
            return friendsList;
        }

        /// <summary>
        /// Get current user details
        /// </summary>
        /// <returns></returns>
        public async Task<UserDetails> GetUserDetail(int userId)
        {
            return await _unitOfWork.Friends.GetById(userId);

        }


        /// <summary>
        /// Add friend
        /// </summary>
        /// <returns></returns>
        public async Task<UserDetails> AddFriends() 
        {
            UserDetails userHareesh= new UserDetails() {Id=1,Name="Hareesh", Age =25, Gender="Male", Location="Banagalore", Friends = new List<UserDetails> { } };
            UserDetails userBryson = new UserDetails() {Id=1,Name="Bryson", Age =10, Gender="Male", Location="Banagalore", Friends = new List<UserDetails> { } };
            UserDetails userBryna = new UserDetails() {Id=1,Name="Bryna", Age =21, Gender="Female", Location="Banagalore", Friends = new List<UserDetails> { } };

            // Establish friendships
            userHareesh.Friends.Add(userBryson);
            userBryson.Friends.Add(userHareesh);
            userBryson.Friends.Add(userBryna);
            userBryna.Friends.Add(userBryson);

            return userHareesh;
            //Below code to add user to database table
            //return await _unitOfWork.Friends.Create(userDetails);
        }


        /// <summary>
        /// Update user details
        /// </summary>
        /// <returns></returns>
        public async Task<int> UpdateUser(UserDetails userDetails)
        {
            return await _unitOfWork.Friends.Update(userDetails.Id, userDetails);
        }

        /// <summary>
        /// Delete friend
        /// </summary>
        /// <returns></returns>
        public async Task<int> DeleteFriend(int productId)
        {
            return await _unitOfWork.Friends.Delete(productId);
        }

    }
}
