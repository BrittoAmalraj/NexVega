﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NexVega.Core.Models;

namespace NexVega.Services.Interfaces
{
    public interface IFriendsService
    {
        Task<IEnumerable<UserDetails>> GetFriendSuggestions(UserDetails userDetails);
        Task<List<string>> GetFriendSuggestionsUsingBFS(string user, Dictionary<string, List<string>> friendLists);
        Task<UserDetails> GetUserDetail(int userId);
        Task<UserDetails> AddFriends();
    }
}
